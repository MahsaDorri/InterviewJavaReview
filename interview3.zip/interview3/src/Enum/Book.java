package Enum;

public enum Book {

A("Java Book", 1996),
    B("C# Book", 1993),
    C("SQL Book", 1900),
    D;
    private String title;
    private int copyRightYear;
    public void setCopyRightYear( int copyRightYear){
        this.copyRightYear = copyRightYear;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public String getTitle(){
        return title;
    }
    public int getCopyRightYear() {
        return copyRightYear;
    }
    Book(String title, int copyRightYear){
        this.title = title;
        this.copyRightYear = copyRightYear;
    }
    Book(){}

    @Override
    public String toString() {
        return "The " + getTitle() + " has been pulished in " + getCopyRightYear();
    }
}
