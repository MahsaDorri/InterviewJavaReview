package Enum;

import java.util.EnumSet;

public class Demo {
    public static void main(String args[]) {
        Course c1 = new Course("E2", "Interview Practice for enum", Book.A);
        System.out.print(c1.toString());

        for (Book bk : EnumSet.range(Book.A, Book.D)) { ////????????????????
            System.out.println(bk.toString());
        }
    } //ctrl + alt +shift +l
}
