public enum CarModel {
    SUV,
    Coupe,
    Convertible,
    Sedan,
    Minivan,
    Truck,
    Hatchback,
    Roadster,
    Station_Wagon;
}
