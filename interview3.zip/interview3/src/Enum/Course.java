package Enum;

public class Course {
    private String courseCode;
    private String courseTitle;
    private Book courseText;
    public Course(){
        this.courseCode = "N/A";
        this.courseTitle= "N/A";
         this.courseText = Book.A;
    }

    public Course(String courseCode, String courseTitle, Book courseText){
        this.courseCode = courseCode;
        this.courseTitle= courseTitle;
        this.courseText = courseText;
    }
    public void setCourseCode(String courseCode){
        this.courseCode = courseCode;
    }
    public String getCourseCode(){
        return courseCode;
    }
    public void setCourseTitle(String courseTitle){
        this.courseTitle = courseTitle;
    }
    public  String getCourseTitle(){
        return courseTitle;
    }
@Override
    public String toString(){
        return "\nThe " + getCourseTitle() + "'s  course code is " + getCourseCode()
                + "\n which need to have " + this.courseText + " ";
}
}
