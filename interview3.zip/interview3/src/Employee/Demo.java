package Employee;

public class Demo {
    public static void main(String[] args) {
        Employee e1 = new Employee("Mahsa", "Dorri");
        Employee e2 = new Employee("Lili", "Dorri");
        Employee e3 = new Employee();
        System.out.println( e1.toString() );
        System.out.println(e2.toString());
        System.out.println( e3.join("Zahra", "Dorri"));

    }
}
