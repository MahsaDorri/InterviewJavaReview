public class demo {
    public static void main(String[] args) {
        Account ac1 = new Account();
        Account ac2 = new Account("Mahsa",90);
        ac1.deposit(15);
        ac2.deposit(10);
        ac1.withDraw(20);
        ac2.withDraw(30);
    }
}
