import java.security.Signature;
import java.util.Date;

public class Singer {
    private String singerId;
    private  String singerName;
    private String lastName;
    private String AlbumName;
    private Date birthDate;

    Singer(){
    }
    Singer(String singerId){
        this.singerId = singerId;
    }
    Singer(String singerId, String singerName, String lastName){
        this.singerId = singerId;
        this.singerName = singerName;
        this.lastName = lastName;
    }
    Singer(String singerId, String singerName, String lastName, String AlbumName){
        this.singerId = singerId;
        this.singerName = singerName;
        this.lastName = lastName;
        this.AlbumName = AlbumName;
    }
    Singer(String singerId, String singerName, String lastName, String AlbumName, Date birthDate){
        this.singerId = singerId;
        this.singerName = singerName;
        this.lastName = lastName;
        this.AlbumName = AlbumName;
        this.birthDate = birthDate;
    }
public void setSingerId(String singerId){
        this.singerId = singerId;
}
public void setSingerName(String singerName){
        this.singerName = singerName;
}

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
     public void setAlbumName(String AlbumName){
        this.AlbumName = AlbumName;
     }
     public  void setBirthDate(Date birthDate){
        this.birthDate = birthDate;
     }
     public String getSingerId(){return singerId;}
    public String getSingerName(){return singerName;}
    public String getlastName(){return lastName;}
    public String getAlbumName(){return AlbumName;}
    public Date getBirthDate(){return birthDate;}

public String toString(){
        return "\\n This singer" + getSingerName() +
                " " + getlastName() + " " + " and it's ID is " + getSingerId() + " and album name"
                + getAlbumName() + "  " + getBirthDate();
}
}
