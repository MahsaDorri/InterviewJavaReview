public class Account {
private String ownerName;
private double balance;

Account(){
    this. ownerName = "ownerName";
    this.balance = 0;
}
Account(String ownerName, double balance){
    this.ownerName = ownerName;
    this.balance = balance;
}

    public double getBalance() {
        return balance;
    }
    public String getOwnerNme(){
    return ownerName;
    }
    public void setOwnerName(String ownerName){
    this.ownerName = ownerName;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
public void deposit(double amount){
    if (amount<0){
        System.out.println("Please Enter the valid amount");
    }else {
        System.out.println("your current balance:" + balance);
        System.out.println("the new deposited amount is:" + amount);
        balance +=amount;
        System.out.println("your new balance is: "+ balance);
    }


}
public void withDraw(double amount){
    if (amount<0){
        System.out.println("please Enter the valid amount");
    } else if (balance- amount <0) {
        System.out.println("You dont have enough money to withdraw.");
    }
    {
        System.out.println("balance is " + balance);
        balance -= amount;
        System.out.println("new balance is: " + balance);
    }
}
}
