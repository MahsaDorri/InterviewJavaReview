import java.util.ArrayList;

public class Dealer {
    ArrayList<Car> carList = new ArrayList<>();

    public ArrayList<Car> getCarList() {
        return carList;
    }

    public void setCarList(ArrayList<Car> carList) {
        this.carList = carList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    private String id;
    private String name;
    private String address;
    Dealer(String id, String name, String address){
        this.id = id;
        this.name = name;
    }
    public void add(String manufacture, int make, String model, double basePrice, CarModel type){
        Car car = new Car(manufacture, make, model, basePrice, type);
        carList.add(car);
    }
    public void showCar(String manufacture){
        for (Car car: getCarList()){
            if(manufacture.equals(car.getManufacture())){
                System.out.print(car);
            }
        }
    }

}
