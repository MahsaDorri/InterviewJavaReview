public class Demo {
    public static void main(String[] args) {
        Singer s1 = new Singer();
        Singer s2 = new Singer("1e", "Mahsa", "Dorri");
        Singer s3 = new Singer("2e", "r","ri", "Asghar" );
        System.out.print(s1.toString());
        System.out.print(s2.toString());
        System.out.print(s3.toString());


    }
}
