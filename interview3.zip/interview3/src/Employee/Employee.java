package Employee;

public class Employee {
private String firstName;
private String lastName;
private int empId;
private static int counter = 100;
public String getFirstName(){
    return firstName;
}
public String getLastname(){
    return lastName;
}
public int getEmpId(){
    return empId;
}
public void setFirstName(String firstName){
    this.firstName = firstName;
}
public void setLastName(String lastName){
    this.lastName = lastName;
}
public String join(String firstName, String lastName){
    return firstName + " " + lastName;
}
Employee(){
   this.firstName = "Unknown";
    this.lastName = "Unknown";
    counter++;
    this.empId = counter;
}
Employee(String firstName, String lastName){
    this. firstName = firstName;
    this.lastName = lastName;
    counter++;
    this.empId = counter;
}
 @Override
    public String toString(){
    return("We have new Employee.Employee and his/ her name is : " + getFirstName() +
             " " + getLastname() + " and her/ his empId is " + getEmpId());
 }
}
