import java.util.ArrayList;

public class Demo {
    public static void main(String[] args) {

        Dealer d1 = new Dealer("564664", "Mahsa", "north york");
        Dealer d2 = new Dealer("896345", "Nazanin", "down town");

        Car c1 = new Car("Honda", 2000, "S500", 20000, CarModel.Sedan);
        Car c2 = new Car("Mazda", 2001, "S550", 28000, CarModel.SUV);
        d1.carList.add(c1);
        d1.carList.add(c2);
        System.out.println( d1.carList.add(c1));
//        List<String> lst = new ArrayList<>();
//        lst.add("Hosein");
//        lst.add("Mahsa");
//        lst.add("Danyal");
//        boolean b = lst.contains("Amir");*/
    }
}
