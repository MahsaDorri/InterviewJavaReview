public class Car {
    private String manufacture;
    private int make;
    private String model;



    private double baseprice;
    private CarModel type;
    private int Id;

    Car(){
        this.manufacture = "N/A";
        this.make = 0;
        this.model = "N/A";
        this.Id = 0;
    }
    Car(String manufacture, int make, String model, double baseprice, CarModel type){
        this.manufacture = manufacture;
        this.make = make;
        this.model = model;
        this.baseprice = baseprice;
        this.type = type;
    }

    public String getManufacture() {
        return manufacture;
    }

    public void setManufacture(String manufacture) {
        this.manufacture = manufacture;
    }

    public int getMake() {
        return make;
    }

    public void setMake(int make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getBaseprice() {
        return baseprice;
    }

    public void setBaseprice(double baseprice) {
        this.baseprice = baseprice;
    }

    public CarModel getType() {
        return type;
    }

    public void setType(CarModel type) {
        this.type = type;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

}
